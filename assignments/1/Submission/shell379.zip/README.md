# CMPUT 379 Assignment 1: Mini Shell

### Usage

- Unzip archive and navigate to directory in terminal
- Run make to generate a "./shell" executable
- Run ./shell to use

### Notes

- Function summary comments are in .h files, technical details on implementations are in .cpp files.
- Any use of external sources are referenced in .h files